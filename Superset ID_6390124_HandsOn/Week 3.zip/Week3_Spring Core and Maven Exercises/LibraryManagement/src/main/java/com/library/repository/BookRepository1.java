package com.library.repository;

public class BookRepository1 {
    public void saveBook(String title) {
        System.out.println("Book saved: " + title);
    }
}
