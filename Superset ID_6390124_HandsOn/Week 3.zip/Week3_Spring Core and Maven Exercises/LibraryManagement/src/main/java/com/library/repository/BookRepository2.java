package com.library.repository;

public class BookRepository2 {
    public void saveBook(String title) {
        System.out.println("BookRepository2: Book saved - " + title);
    }
}
