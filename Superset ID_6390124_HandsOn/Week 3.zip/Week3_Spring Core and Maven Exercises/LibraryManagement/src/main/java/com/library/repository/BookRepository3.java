package com.library.repository;

public class BookRepository3 {
    public void saveBook(String title) {
        System.out.println("BookRepository3: Book saved - " + title);
    }
}
