package com.cognizant.orm_query_methods_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrmQueryMethodsDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
