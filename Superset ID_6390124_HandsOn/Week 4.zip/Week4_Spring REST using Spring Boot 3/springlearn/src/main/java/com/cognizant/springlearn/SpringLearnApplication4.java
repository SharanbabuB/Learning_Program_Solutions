package com.cognizant.springlearn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringLearnApplication4 {
    public static void main(String[] args) {
        SpringApplication.run(SpringLearnApplication4.class, args);
    }
}
